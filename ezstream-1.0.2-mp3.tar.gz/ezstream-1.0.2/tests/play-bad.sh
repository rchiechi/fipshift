#!/bin/sh

echo "$(cat playlist-bad.txt)"
